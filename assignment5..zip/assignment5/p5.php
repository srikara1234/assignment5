<html>
<head>
    <title>Random</title>
    <style type="text/css">
        p {
color:white;
font-size:50px;
position: absolute;
top: 20%;
left: 40%;
transform: translate(-50%, -50%);
}
    </style>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
</head>
<body style="background-color: black;color: yellow;">
    <center>
        <form method="post">
    <table border="1">
        <tr>
            <th colspan="4" style="text-align: center;"> Bank</th>
        </tr>        
        <tr>
            <th><a role="button" class="btn btn-light" href="p5add.php"> Create</a> </th>
            <th><a role="button" class="btn btn-light" href="p5deposit.php"> Deposit</a></th>
            <th><a role="button" class="btn btn-light" href="p5withdraw.php"> Withdraw</a></th>
            <th><a role="button" class="btn btn-light" href="p5balance.php"> Balance Enquiry</a></th>
        </tr> 
    </table>
</form>
    </center>
</body>
</html>